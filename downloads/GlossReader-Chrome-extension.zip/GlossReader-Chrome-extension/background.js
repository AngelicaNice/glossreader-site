// src/shared/types.ts
var BROWSER_BOOK_TITLE = "\u0418\u0437 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0430";
var HOST_NAME = "app.glossreader.host";
var DEFAULT_SETTINGS = {
  enabledLevels: ["A1", "A2", "B1", "B2", "C1", "C2", "TOP1000", "TOP5000", "TOP20000", "RARE"],
  levelsOn: true,
  alwaysSites: [],
  excludeHosts: []
};

// src/background/lexmerge.ts
var MAX_LEXICON_BYTES = 16 << 20;
function emptyState() {
  return { known: {}, vocab: {}, outbox: { known: {}, vocab: {} }, removedKnown: {} };
}
function normLemma(s) {
  if (typeof s !== "string") return "";
  const l = s.trim().toLowerCase();
  return l === "__proto__" ? "" : l;
}
var has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
function earlierAt(a, b) {
  a = a.trim();
  b = b.trim();
  if (a === "") return b;
  if (b === "") return a;
  return b < a ? b : a;
}
function mergeVocab(a, b) {
  const out = { ...a };
  if (!out.pos) out.pos = b.pos;
  if (!out.translation) out.translation = b.translation;
  if (!out.context) out.context = b.context;
  if (!out.surface) out.surface = b.surface;
  if (!out.added_at || b.added_at && b.added_at < out.added_at) out.added_at = b.added_at;
  return dropEmpty(out);
}
function dropEmpty(v) {
  const out = { book_title: v.book_title, lemma: v.lemma };
  if (v.pos) out.pos = v.pos;
  if (v.translation) out.translation = v.translation;
  if (v.context) out.context = v.context;
  if (v.surface) out.surface = v.surface;
  if (v.added_at) out.added_at = v.added_at;
  return out;
}
function cleanVocab(v) {
  if (typeof v !== "object" || v === null) return null;
  const r = v;
  const str = (x) => typeof x === "string" ? x : "";
  const title = str(r.book_title).trim();
  const lemma = normLemma(r.lemma);
  if (title === "" || lemma === "") return null;
  return dropEmpty({
    book_title: title,
    lemma,
    pos: str(r.pos),
    translation: str(r.translation),
    context: str(r.context),
    surface: str(r.surface),
    added_at: str(r.added_at)
  });
}
var isBrowserBook = (title) => title.trim().toLowerCase() === BROWSER_BOOK_TITLE.toLowerCase();
function applySnapshot(state, snap, mode) {
  const stats = { knownAdded: 0, knownSame: 0, knownIgnored: 0, vocabAdded: 0, vocabSame: 0 };
  for (const d of snap.dismissed ?? []) {
    const r = d;
    const lemma = normLemma(r?.lemma);
    if (lemma === "") continue;
    const at = typeof r?.at === "string" ? r.at.trim() : "";
    if (has(state.removedKnown, lemma)) {
      if (at <= state.removedKnown[lemma]) {
        stats.knownIgnored++;
        continue;
      }
      delete state.removedKnown[lemma];
    }
    if (has(state.known, lemma)) {
      stats.knownSame++;
      state.known[lemma] = earlierAt(state.known[lemma], at);
    } else {
      stats.knownAdded++;
      state.known[lemma] = at;
      if (mode === "import") state.outbox.known[lemma] = at;
    }
    if (mode === "host") delete state.outbox.known[lemma];
  }
  for (const raw of snap.vocab ?? []) {
    const v = cleanVocab(raw);
    if (!v) continue;
    const mine = isBrowserBook(v.book_title);
    if (has(state.vocab, v.lemma)) {
      stats.vocabSame++;
      state.vocab[v.lemma] = mergeVocab(state.vocab[v.lemma], v);
    } else {
      stats.vocabAdded++;
      state.vocab[v.lemma] = v;
      if (mode === "import" && mine) state.outbox.vocab[v.lemma] = v;
    }
    if (mode === "host" && mine) delete state.outbox.vocab[v.lemma];
  }
  return stats;
}

// src/background/packfile.ts
function unpackEntry(rec) {
  const r = Array.isArray(rec) ? rec : [];
  const s = (x) => typeof x === "string" ? x : "";
  return {
    cefr: s(r[0]),
    band: s(r[1]),
    ipa: s(r[2]),
    pos: s(r[3]),
    tr: Array.isArray(r[4]) ? r[4].filter((t) => typeof t === "string") : []
  };
}
var WS = /* @__PURE__ */ new Set([32, 10, 13, 9]);
var Scanner = class {
  buf = "";
  pos = 0;
  eof = false;
  it;
  constructor(chunks) {
    this.it = chunks[Symbol.asyncIterator]();
  }
  /** Appends the next chunk; false when the input is over. */
  async fill() {
    if (this.eof) return false;
    const r = await this.it.next();
    if (r.done) {
      this.eof = true;
      return false;
    }
    this.buf = this.buf.slice(this.pos) + r.value;
    this.pos = 0;
    return true;
  }
  /** Skips whitespace and returns the next character code, or -1 at the end. */
  async peek() {
    for (; ; ) {
      while (this.pos < this.buf.length) {
        const c = this.buf.charCodeAt(this.pos);
        if (!WS.has(c) && c !== 65279) return c;
        this.pos++;
      }
      if (!await this.fill()) return -1;
    }
  }
  async expect(ch) {
    const c = await this.peek();
    if (c !== ch.charCodeAt(0)) throw new Error(`pack.json: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \xAB${ch}\xBB, \u043D\u0430\u0439\u0434\u0435\u043D\u043E ${c < 0 ? "\u043A\u043E\u043D\u0435\u0446 \u0444\u0430\u0439\u043B\u0430" : "\xAB" + String.fromCharCode(c) + "\xBB"}`);
    this.pos++;
  }
  /** Text of the next complete JSON value (string, number, literal, array or object). */
  async value() {
    const first = await this.peek();
    if (first < 0) throw new Error("pack.json: \u0444\u0430\u0439\u043B \u043E\u0431\u043E\u0440\u0432\u0430\u043D");
    let i = this.pos;
    let depth = 0;
    let inStr = false;
    let esc = false;
    for (; ; ) {
      while (i < this.buf.length) {
        const c = this.buf.charCodeAt(i);
        if (inStr) {
          if (esc) esc = false;
          else if (c === 92) esc = true;
          else if (c === 34) {
            inStr = false;
            if (depth === 0) return this.take(i + 1);
          }
        } else if (c === 34) {
          inStr = true;
        } else if (c === 91 || c === 123) {
          depth++;
        } else if (c === 93 || c === 125) {
          depth--;
          if (depth === 0) return this.take(i + 1);
          if (depth < 0) {
            return this.take(i);
          }
        } else if (depth === 0 && (c === 44 || WS.has(c))) {
          return this.take(i);
        }
        i++;
      }
      const consumed = this.pos;
      if (!await this.fill()) {
        if (inStr || depth !== 0) throw new Error("pack.json: \u0444\u0430\u0439\u043B \u043E\u0431\u043E\u0440\u0432\u0430\u043D");
        return this.take(i);
      }
      i -= consumed;
    }
  }
  take(end) {
    const s = this.buf.slice(this.pos, end);
    this.pos = end;
    return s;
  }
};
async function* readPack(chunks, batchSize = 2e3) {
  const sc = new Scanner(chunks);
  await sc.expect("{");
  if (await sc.peek() === 125) return;
  for (; ; ) {
    const key = JSON.parse(await sc.value());
    await sc.expect(":");
    if (key !== "words") {
      yield { type: "meta", key, value: JSON.parse(await sc.value()) };
    } else {
      await sc.expect("{");
      let batch = [];
      if (await sc.peek() === 125) {
        sc.pos++;
      } else {
        for (; ; ) {
          const lemma = JSON.parse(await sc.value());
          await sc.expect(":");
          const rec = JSON.parse(await sc.value());
          batch.push([lemma, rec]);
          if (batch.length >= batchSize) {
            yield { type: "words", words: batch };
            batch = [];
          }
          const c2 = await sc.peek();
          sc.pos++;
          if (c2 === 125) break;
          if (c2 !== 44) throw new Error("pack.json: \u0432 \u0441\u043F\u0438\u0441\u043A\u0435 \u0441\u043B\u043E\u0432 \u043E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u0437\u0430\u043F\u044F\u0442\u0430\u044F");
        }
        if (batch.length) yield { type: "words", words: batch };
      }
    }
    const c = await sc.peek();
    sc.pos++;
    if (c === 125) return;
    if (c !== 44) throw new Error("pack.json: \u043E\u0436\u0438\u0434\u0430\u043B\u0430\u0441\u044C \u0437\u0430\u043F\u044F\u0442\u0430\u044F \u0438\u043B\u0438 \u043A\u043E\u043D\u0435\u0446 \u043E\u0431\u044A\u0435\u043A\u0442\u0430");
  }
}
async function* textChunks(body, onBytes) {
  const reader = body.getReader();
  const dec = new TextDecoder();
  for (; ; ) {
    const { done: done2, value } = await reader.read();
    if (done2) break;
    onBytes?.(value.byteLength);
    const s = dec.decode(value, { stream: true });
    if (s) yield s;
  }
  const rest = dec.decode();
  if (rest) yield rest;
}

// src/background/store.ts
var LOCK_NAME = "gr-store";
function nowStamp(d = /* @__PURE__ */ new Date()) {
  return d.toISOString().slice(0, 19).replace("T", " ");
}
async function withStore(fn) {
  if (typeof navigator !== "undefined" && navigator.locks) {
    return navigator.locks.request(LOCK_NAME, fn);
  }
  return fn();
}
async function readWords() {
  const r = await chrome.storage.local.get(["known", "vocab", "outbox", "removedKnown"]);
  const s = emptyState();
  if (isMap(r.known)) s.known = r.known;
  if (isMap(r.vocab)) s.vocab = r.vocab;
  if (isMap(r.removedKnown)) s.removedKnown = r.removedKnown;
  if (isMap(r.outbox)) {
    const o = r.outbox;
    if (isMap(o.known)) s.outbox.known = o.known;
    if (isMap(o.vocab)) s.outbox.vocab = o.vocab;
  }
  return s;
}
async function writeWords(s) {
  await chrome.storage.local.set({ known: s.known, vocab: s.vocab, outbox: s.outbox, removedKnown: s.removedKnown });
}
function updateWords(fn) {
  return withStore(async () => {
    const s = await readWords();
    const out = await fn(s);
    await writeWords(s);
    return out;
  });
}
function isMap(x) {
  return typeof x === "object" && x !== null && !Array.isArray(x);
}
async function getSettings() {
  const r = await chrome.storage.local.get("settings");
  return normalizeSettings(r.settings);
}
function normalizeSettings(raw) {
  const o = isMap(raw) ? raw : {};
  const list = (x, fallback) => Array.isArray(x) ? x.filter((v) => typeof v === "string") : fallback;
  return {
    enabledLevels: list(o.enabledLevels, DEFAULT_SETTINGS.enabledLevels),
    levelsOn: typeof o.levelsOn === "boolean" ? o.levelsOn : DEFAULT_SETTINGS.levelsOn,
    alwaysSites: list(o.alwaysSites, []),
    excludeHosts: list(o.excludeHosts, [])
  };
}
function updateSettings(fn) {
  return withStore(async () => {
    const s = await getSettings();
    fn(s);
    await chrome.storage.local.set({ settings: s });
    return s;
  });
}
async function getHostStatus() {
  const r = await chrome.storage.local.get("host");
  return isMap(r.host) ? r.host : { connected: false };
}
async function setHostStatus(h) {
  await chrome.storage.local.set({ host: h });
}
async function getPackStatus() {
  const r = await chrome.storage.local.get("packState");
  return isMap(r.packState) ? r.packState : { ready: false, loading: false, progress: 0 };
}
async function setPackStatus(p) {
  await chrome.storage.local.set({ packState: p });
}

// src/background/pack.ts
var DB_NAME = "glossreader-pack";
var WORDS = "words";
var META = "meta";
var META_KEY = "pack";
var BATCH = 2e3;
var PROGRESS_EVERY_MS = 400;
var dbPromise = null;
function openDb() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore(WORDS);
        req.result.createObjectStore(META);
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onclose = db.onversionchange = () => {
          dbPromise = null;
          db.close();
        };
        resolve(db);
      };
      req.onerror = () => {
        dbPromise = null;
        reject(req.error);
      };
    });
  }
  return dbPromise;
}
function done(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error ?? new Error("IndexedDB: \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u044F \u043F\u0440\u0435\u0440\u0432\u0430\u043D\u0430"));
  });
}
function reqValue(r) {
  return new Promise((resolve, reject) => {
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function lookupWords(lemmas) {
  const db = await openDb();
  const tx = db.transaction(WORDS, "readonly");
  const store = tx.objectStore(WORDS);
  const out = {};
  const seen = /* @__PURE__ */ new Set();
  const jobs = [];
  for (const lemma of lemmas) {
    if (typeof lemma !== "string" || seen.has(lemma)) continue;
    seen.add(lemma);
    jobs.push(
      reqValue(store.get(lemma.trim().toLowerCase())).then((rec) => {
        if (rec !== void 0) out[lemma] = unpackEntry(rec);
      })
    );
  }
  await Promise.all(jobs);
  return out;
}
async function fetchMetaFile() {
  try {
    const r = await fetch(chrome.runtime.getURL("pack/pack.meta.json"));
    if (!r.ok) return null;
    const m = await r.json();
    return typeof m.version === "number" ? m : null;
  } catch {
    return null;
  }
}
var sigOf = (m) => `${m.version}|${m.built}|${m.count}|${m.bytes}`;
var loading = null;
function ensurePack(force = false) {
  if (!loading) {
    loading = run(force).finally(() => {
      loading = null;
    });
  }
  return loading;
}
async function run(force) {
  const file = await fetchMetaFile();
  let stored;
  let storedStatus;
  try {
    const db = await openDb();
    stored = await reqValue(db.transaction(META).objectStore(META).get(META_KEY));
    storedStatus = await getPackStatus();
  } catch (e) {
    return fail(e);
  }
  if (!force && stored?.complete && storedStatus?.ready && (!file || stored.sig === sigOf(file))) {
    return storedStatus;
  }
  try {
    return await load(file);
  } catch (e) {
    return fail(e);
  }
}
async function fail(e) {
  const st = {
    ready: false,
    loading: false,
    progress: 0,
    error: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0441\u043B\u043E\u0432\u0430\u0440\u044C: " + (e instanceof Error ? e.message : String(e))
  };
  await setPackStatus(st);
  return st;
}
async function load(file) {
  await setPackStatus({ ready: false, loading: true, progress: 0 });
  const db = await openDb();
  {
    const tx = db.transaction([WORDS, META], "readwrite");
    tx.objectStore(WORDS).clear();
    tx.objectStore(META).delete(META_KEY);
    await done(tx);
  }
  const res = await fetch(chrome.runtime.getURL("pack/pack.json"));
  if (!res.ok || !res.body) throw new Error(`pack.json \u043D\u0435 \u043E\u0442\u043A\u0440\u044B\u043B\u0441\u044F (${res.status})`);
  const total = file?.bytes || Number(res.headers.get("content-length")) || 0;
  let read = 0;
  let count = 0;
  let version = file?.version;
  let built = file?.built;
  let lastReport = 0;
  const chunks = textChunks(res.body, (n) => {
    read += n;
  });
  for await (const ev of readPack(chunks, BATCH)) {
    if (ev.type === "meta") {
      if (ev.key === "version" && typeof ev.value === "number") version = ev.value;
      if (ev.key === "built" && typeof ev.value === "string") built = ev.value;
      continue;
    }
    const tx = db.transaction(WORDS, "readwrite");
    const store = tx.objectStore(WORDS);
    for (const [lemma, rec] of ev.words) store.put(rec, lemma);
    await done(tx);
    count += ev.words.length;
    const now = Date.now();
    if (now - lastReport > PROGRESS_EVERY_MS) {
      lastReport = now;
      await setPackStatus({ ready: false, loading: true, progress: total ? Math.min(0.99, read / total) : 0, count });
    }
  }
  const sig = file ? sigOf(file) : `${version}|${built}|${count}|${read}`;
  {
    const tx = db.transaction(META, "readwrite");
    const m = { sig, complete: true };
    tx.objectStore(META).put(m, META_KEY);
    await done(tx);
  }
  const st = { ready: true, loading: false, progress: 1, count, version, built };
  await setPackStatus(st);
  return st;
}

// src/background/sites.ts
var SCRIPT_PREFIX = "gr:";
var MENU_ALWAYS = "gr-always";
var MENU_NEVER = "gr-never";
var MENU_OPTIONS = "gr-options";
function siteOf(url) {
  if (!url) return null;
  try {
    const u = new URL(url);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    if (u.hostname === "") return null;
    return { origin: u.origin, host: u.hostname };
  } catch {
    return null;
  }
}
function parseSiteInput(text) {
  const t = text.trim();
  if (t === "" || /\s/.test(t)) return null;
  const site = siteOf(/^[a-z][a-z0-9+.-]*:\/\//i.test(t) ? t : "https://" + t);
  if (!site) return null;
  if (!site.host.includes(".") && site.host !== "localhost") return null;
  return site;
}
var patternOf = (origin) => origin + "/*";
function noReceiver(e) {
  const m = e instanceof Error ? e.message : String(e);
  return m.includes("Receiving end does not exist") || m.includes("Could not establish connection");
}
async function command(tabId, msg) {
  try {
    const reply = await chrome.tabs.sendMessage(tabId, msg);
    return typeof reply === "object" && reply !== null ? reply : {};
  } catch (e) {
    if (noReceiver(e)) return null;
    return {};
  }
}
async function inject(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return true;
  } catch {
    return false;
  }
}
async function toggleInTab(tab) {
  const id = tab.id;
  if (id === void 0) return;
  if (await command(id, { type: "toggle" }) !== null) return;
  await inject(id);
}
async function setEnabled(tabId, wanted) {
  const first = await command(tabId, { type: "toggle" });
  if (first === null) {
    if (wanted) await inject(tabId);
    return;
  }
  if (typeof first.enabled === "boolean" && first.enabled !== wanted) await command(tabId, { type: "toggle" });
}
async function broadcastRescan() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({});
  } catch {
    return;
  }
  await Promise.all(
    tabs.map(async (t) => {
      if (t.id === void 0) return;
      try {
        await chrome.tabs.sendMessage(t.id, { type: "rescan" });
      } catch {
      }
    })
  );
}
var reconciling = Promise.resolve();
function reconcileScripts() {
  reconciling = reconciling.then(doReconcile, doReconcile);
  return reconciling;
}
async function doReconcile() {
  try {
    const settings = await getSettings();
    const wanted = /* @__PURE__ */ new Set();
    for (const o of settings.alwaysSites) {
      const site = siteOf(o);
      if (!site) continue;
      let allowed = false;
      try {
        allowed = await chrome.permissions.contains({ origins: [patternOf(site.origin)] });
      } catch {
        allowed = false;
      }
      if (allowed) wanted.add(site.origin);
    }
    const registered = await chrome.scripting.getRegisteredContentScripts();
    const have = /* @__PURE__ */ new Set();
    const drop = [];
    for (const s of registered) {
      if (!s.id.startsWith(SCRIPT_PREFIX)) continue;
      const origin = s.id.slice(SCRIPT_PREFIX.length);
      if (wanted.has(origin)) have.add(origin);
      else drop.push(s.id);
    }
    if (drop.length) await chrome.scripting.unregisterContentScripts({ ids: drop });
    const add = [...wanted].filter((o) => !have.has(o));
    if (add.length) {
      await chrome.scripting.registerContentScripts(
        add.map((origin) => ({
          id: SCRIPT_PREFIX + origin,
          matches: [patternOf(origin)],
          js: ["content.js"],
          runAt: "document_idle",
          persistAcrossSessions: true
        }))
      );
    }
  } catch (e) {
    console.warn("GlossReader: \u043D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0433\u043B\u0430\u0441\u043E\u0432\u0430\u0442\u044C \u0441\u043A\u0440\u0438\u043F\u0442\u044B \u0441\u0430\u0439\u0442\u043E\u0432", e);
  }
}
async function addAlwaysSite(site) {
  const allowed = await chrome.permissions.contains({ origins: [patternOf(site.origin)] });
  if (!allowed) return "\u0414\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0441\u0430\u0439\u0442\u0430 \u043D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C\xBB \u0435\u0449\u0451 \u0440\u0430\u0437 \u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043E\u0441\u0442\u0443\u043F.";
  await updateSettings((s) => {
    if (!s.alwaysSites.includes(site.origin)) s.alwaysSites.push(site.origin);
    s.excludeHosts = s.excludeHosts.filter((h) => h !== site.host);
  });
  await reconcileScripts();
  return null;
}
async function removeAlwaysSite(origin) {
  await updateSettings((s) => {
    s.alwaysSites = s.alwaysSites.filter((o) => o !== origin);
  });
  await reconcileScripts();
}
async function excludeSite(site) {
  await updateSettings((s) => {
    s.alwaysSites = s.alwaysSites.filter((o) => siteOf(o)?.host !== site.host);
    if (!s.excludeHosts.includes(site.host)) s.excludeHosts.push(site.host);
  });
  await reconcileScripts();
}
async function unexcludeSite(host2) {
  await updateSettings((s) => {
    s.excludeHosts = s.excludeHosts.filter((h) => h !== host2);
  });
}
async function createMenus() {
  await chrome.contextMenus.removeAll();
  const items = [
    [MENU_ALWAYS, "\u0412\u0441\u0435\u0433\u0434\u0430 \u043F\u043E\u0434\u0441\u0432\u0435\u0447\u0438\u0432\u0430\u0442\u044C \u043D\u0430 \u044D\u0442\u043E\u043C \u0441\u0430\u0439\u0442\u0435"],
    [MENU_NEVER, "\u0411\u043E\u043B\u044C\u0448\u0435 \u043D\u0435 \u043F\u043E\u0434\u0441\u0432\u0435\u0447\u0438\u0432\u0430\u0442\u044C \u043D\u0430 \u044D\u0442\u043E\u043C \u0441\u0430\u0439\u0442\u0435"],
    [MENU_OPTIONS, "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438"]
  ];
  for (const [id, title] of items) chrome.contextMenus.create({ id, title, contexts: ["action"] });
}
async function onMenuClick(info, tab) {
  if (info.menuItemId === MENU_OPTIONS) {
    await chrome.runtime.openOptionsPage();
    return;
  }
  const site = siteOf(tab?.url);
  if (!site) return;
  if (info.menuItemId === MENU_ALWAYS) {
    const granted = await chrome.permissions.request({ origins: [patternOf(site.origin)] });
    if (!granted) return;
    if (await addAlwaysSite(site) !== null) return;
    if (tab?.id !== void 0) await setEnabled(tab.id, true);
  } else if (info.menuItemId === MENU_NEVER) {
    await excludeSite(site);
    if (tab?.id !== void 0) await setEnabled(tab.id, false);
  }
}

// src/background/native.ts
var NOT_CONNECTED = "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E: \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u2192 \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0431\u0440\u0430\u0443\u0437\u0435\u0440";
var HostError = class extends Error {
  /** The app answered, and said no (as opposed to not being reachable). */
  fromApp;
  constructor(message, fromApp = false) {
    super(message);
    this.fromApp = fromApp;
  }
};
function explainDisconnect(reason) {
  const r = (reason ?? "").toLowerCase();
  if (r.includes("not found")) return NOT_CONNECTED;
  if (r.includes("forbidden")) {
    return "\u0411\u0440\u0430\u0443\u0437\u0435\u0440\u0443 \u0437\u0430\u043F\u0440\u0435\u0449\u0451\u043D \u0434\u043E\u0441\u0442\u0443\u043F \u043A \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044E GlossReader: \u0432 GlossReader \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u2192 \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u0435\u0449\u0451 \u0440\u0430\u0437";
  }
  if (r.includes("failed to start")) {
    return "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u0434\u043B\u044F \u0441\u0432\u044F\u0437\u0438 \u0441 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u043E\u043C. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 GlossReader \u2192 \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u2192 \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0431\u0440\u0430\u0443\u0437\u0435\u0440";
  }
  if (r.includes("has exited") || r.includes("exited")) {
    return "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u0437\u0430\u043A\u0440\u044B\u043B\u043E \u0441\u0432\u044F\u0437\u044C \u0441 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u043E\u043C. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \xAB\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u0432\u044F\u0437\u044C\xBB \u0435\u0449\u0451 \u0440\u0430\u0437";
  }
  if (r.includes("invalid native messaging host name")) return NOT_CONNECTED;
  if (r === "") return "\u0421\u0432\u044F\u0437\u044C \u0441 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C GlossReader \u043E\u0431\u043E\u0440\u0432\u0430\u043B\u0430\u0441\u044C";
  return "\u0421\u0432\u044F\u0437\u044C \u0441 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C GlossReader \u043D\u0435 \u0443\u0434\u0430\u043B\u0430\u0441\u044C: " + reason;
}
var FIRST_PAUSE_MS = 5e3;
var MAX_PAUSE_MS = 5 * 6e4;
var DEFAULT_TIMEOUT_MS = 3e4;
var NativeClient = class {
  constructor(hostName = HOST_NAME) {
    this.hostName = hostName;
  }
  hostName;
  port = null;
  pending = /* @__PURE__ */ new Map();
  nextId = 1;
  /** No new connection attempts before this time, after a failed one. */
  notBefore = 0;
  pause = FIRST_PAUSE_MS;
  lastError = NOT_CONNECTED;
  /** Tests make it short. */
  defaultTimeoutMs = DEFAULT_TIMEOUT_MS;
  /** How long until a new connection attempt is allowed (0 when it is). */
  pauseLeftMs() {
    return Math.max(0, this.notBefore - Date.now());
  }
  /**
   * Sends one command and waits for the reply with the same id. `force`
   * ignores the pause after a failure (a person pressed a button).
   * Rejects with HostError.
   */
  async request(cmd, body = {}, opts = {}) {
    const port = this.ensurePort(opts.force === true);
    const id = this.nextId++;
    const reply = await new Promise((resolve, reject) => {
      const timer2 = setTimeout(() => {
        this.pending.delete(id);
        this.drop(port);
        reject(new HostError("\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u043D\u0435 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442"));
      }, opts.timeoutMs ?? this.defaultTimeoutMs);
      this.pending.set(id, { port, resolve, reject, timer: timer2 });
      try {
        port.postMessage({ id, cmd, ...body });
      } catch (e) {
        clearTimeout(timer2);
        this.pending.delete(id);
        reject(new HostError(explainDisconnect(e instanceof Error ? e.message : String(e))));
      }
    });
    if (reply.ok !== true) {
      const text = typeof reply.error === "string" && reply.error.trim() !== "" ? reply.error : "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u0432\u0435\u0440\u043D\u0443\u043B\u043E \u043E\u0448\u0438\u0431\u043A\u0443";
      throw new HostError(text, true);
    }
    return reply;
  }
  /** Closes the port; the next request opens a new one. */
  close() {
    if (this.port) this.drop(this.port);
  }
  get connected() {
    return this.port !== null;
  }
  ensurePort(force) {
    if (this.port) return this.port;
    if (!force && Date.now() < this.notBefore) throw new HostError(this.lastError);
    let port;
    try {
      port = chrome.runtime.connectNative(this.hostName);
    } catch (e) {
      this.failed(explainDisconnect(e instanceof Error ? e.message : String(e)));
      throw new HostError(this.lastError);
    }
    const openedAt = Date.now();
    let answered = false;
    port.onMessage.addListener((msg) => {
      answered = true;
      this.pause = FIRST_PAUSE_MS;
      const m = msg;
      const p = typeof m?.id === "number" ? this.pending.get(m.id) : void 0;
      if (!p) return;
      this.pending.delete(m.id);
      clearTimeout(p.timer);
      p.resolve(m);
    });
    port.onDisconnect.addListener(() => {
      const reason = chrome.runtime.lastError?.message;
      if (this.port === port) this.port = null;
      const text = explainDisconnect(reason);
      if (!answered && Date.now() - openedAt < 1e4) this.failed(text);
      else this.lastError = text;
      this.rejectAll(port, text);
    });
    this.port = port;
    return port;
  }
  failed(text) {
    this.lastError = text;
    this.notBefore = Date.now() + this.pause;
    this.pause = Math.min(this.pause * 2, MAX_PAUSE_MS);
  }
  drop(port) {
    if (this.port === port) this.port = null;
    try {
      port.disconnect();
    } catch {
    }
  }
  rejectAll(port, text) {
    for (const [id, p] of this.pending) {
      if (p.port !== port) continue;
      clearTimeout(p.timer);
      p.reject(new HostError(text));
      this.pending.delete(id);
    }
  }
};

// src/background/sync.ts
var host = new NativeClient();
var ADD_CHUNK = 2e3;
var MAX_PAGES = 500;
var WAKE_SYNC_MIN_AGE_MS = 6e4;
var RETRIES = 3;
var running = null;
var timer;
function scheduleSync(delayMs = 2e3, tries = 0) {
  clearTimeout(timer);
  timer = setTimeout(() => {
    timer = void 0;
    void syncNow().then((st) => {
      if (!st.connected && tries < RETRIES) scheduleSync(Math.max(host.pauseLeftMs() + 250, 3e3), tries + 1);
    }).catch(() => {
    });
  }, delayMs);
}
async function syncIfStale() {
  const st = await getHostStatus();
  const at = st.checkedAt ? Date.parse(st.checkedAt) : 0;
  if (Date.now() - at > WAKE_SYNC_MIN_AGE_MS) await syncNow().catch(() => {
  });
}
function syncNow(force = false) {
  if (!running) {
    running = attempt(force, true).finally(() => {
      running = null;
    });
  }
  return running;
}
function checkHost() {
  return attempt(true, false);
}
async function attempt(force, full) {
  const prev = await getHostStatus();
  const checkedAt = (/* @__PURE__ */ new Date()).toISOString();
  let version;
  let lexicon;
  try {
    const ping = await host.request("ping", {}, { force });
    version = typeof ping.version === "string" ? ping.version : void 0;
    lexicon = typeof ping.lexicon === "string" ? ping.lexicon : void 0;
    if (!full) {
      if (!lexicon) {
        throw new HostError("\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u043D\u0430\u0439\u0434\u0435\u043D\u043E, \u043D\u043E \u043F\u0430\u043F\u043A\u0430 lexicon.json \u0432 \u043D\u0451\u043C \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u0430: GlossReader \u2192 \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438", true);
      }
      return await save({ connected: true, version, lexicon, syncedAt: prev.syncedAt, checkedAt });
    }
    await pullAll();
    const sent = await pushOutbox();
    if (sent) await pullAll();
    return await save({ connected: true, version, lexicon, syncedAt: checkedAt, checkedAt });
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e);
    if (!prev.connected && prev.error === error && !version) return prev;
    return save({ connected: false, error, version, lexicon, syncedAt: prev.syncedAt, checkedAt });
  }
}
async function save(st) {
  const clean = { connected: st.connected };
  for (const k of ["error", "version", "lexicon", "syncedAt", "checkedAt"]) {
    if (st[k] !== void 0 && st[k] !== "") clean[k] = st[k];
  }
  await setHostStatus(clean);
  return clean;
}
async function pullAll() {
  const snap = { known: [], vocab: [] };
  let cursor;
  for (let page = 0; ; page++) {
    if (page >= MAX_PAGES) throw new HostError("\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u043E\u0442\u0434\u0430\u0451\u0442 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u044B\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \u0441\u043B\u043E\u0432");
    const r = await host.request("snapshot", cursor === void 0 ? {} : { cursor });
    if (!Array.isArray(r.known) || !Array.isArray(r.vocab)) {
      throw new HostError("\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u043E\u0442\u0432\u0435\u0442\u0438\u043B\u043E \u043D\u0435 \u0442\u0430\u043A, \u043A\u0430\u043A \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C: \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 GlossReader \u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435");
    }
    snap.known.push(...r.known);
    snap.vocab.push(...r.vocab);
    if (typeof r.next !== "string" || r.next === "") break;
    if (r.next === cursor) throw new HostError("\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u0437\u0430\u0446\u0438\u043A\u043B\u0438\u043B\u043E \u0441\u043F\u0438\u0441\u043E\u043A \u0441\u043B\u043E\u0432");
    cursor = r.next;
  }
  await updateWords((s) => {
    applySnapshot(s, { dismissed: snap.known, vocab: snap.vocab }, "host");
  });
}
async function pushOutbox() {
  const { outbox } = await readWords();
  const known = Object.entries(outbox.known).map(([lemma, at]) => ({ lemma, at }));
  const vocab = Object.values(outbox.vocab).map(wire);
  if (known.length === 0 && vocab.length === 0) return false;
  for (let i = 0; i < known.length; i += ADD_CHUNK) {
    await host.request("add", { known: known.slice(i, i + ADD_CHUNK) });
  }
  for (let i = 0; i < vocab.length; i += ADD_CHUNK) {
    await host.request("add", { vocab: vocab.slice(i, i + ADD_CHUNK) });
  }
  return true;
}
function wire(v) {
  const out = { book_title: v.book_title, lemma: v.lemma };
  if (v.pos) out.pos = v.pos;
  if (v.translation) out.translation = v.translation;
  if (v.context) out.context = v.context;
  if (v.surface) out.surface = v.surface;
  if (v.added_at) out.added_at = v.added_at;
  return out;
}

// src/background/messages.ts
var MAX_LOOKUP = 2e3;
var MAX_CONTEXT = 600;
var MAX_FIELD = 200;
var fail2 = (error) => ({ ok: false, error });
var clip = (x, max) => typeof x === "string" ? x.trim().slice(0, max) : "";
async function handleMessage(msg, fromExtensionPage) {
  const m = msg;
  if (typeof m !== "object" || m === null || typeof m.type !== "string") return fail2("\u041D\u0435\u043F\u043E\u043D\u044F\u0442\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441");
  switch (m.type) {
    case "lookup": {
      if (!Array.isArray(m.lemmas) || m.lemmas.some((l) => typeof l !== "string")) return fail2("\u041D\u0443\u0436\u0435\u043D \u0441\u043F\u0438\u0441\u043E\u043A \u0441\u043B\u043E\u0432");
      if (m.lemmas.length > MAX_LOOKUP) return fail2(`\u0417\u0430 \u043E\u0434\u0438\u043D \u0437\u0430\u043F\u0440\u043E\u0441 \u043C\u043E\u0436\u043D\u043E \u0441\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u043D\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 ${MAX_LOOKUP} \u0441\u043B\u043E\u0432`);
      if (!(await getPackStatus()).ready) return { ok: true, info: {}, packReady: false };
      return { ok: true, info: await lookupWords(m.lemmas), packReady: true };
    }
    case "getState":
      return {
        ok: true,
        settings: await getSettings(),
        packReady: (await getPackStatus()).ready,
        hostConnected: (await getHostStatus()).connected
      };
    case "markKnown": {
      const lemma = normLemma(m.lemma);
      if (lemma === "") return fail2("\u041F\u0443\u0441\u0442\u043E\u0435 \u0441\u043B\u043E\u0432\u043E");
      const added = await updateWords((s) => {
        delete s.removedKnown[lemma];
        if (has(s.known, lemma)) return false;
        s.known[lemma] = nowStamp();
        s.outbox.known[lemma] = s.known[lemma];
        return true;
      });
      if (added) scheduleSync();
      return { ok: true };
    }
    case "unmarkKnown": {
      const lemma = normLemma(m.lemma);
      if (lemma === "") return fail2("\u041F\u0443\u0441\u0442\u043E\u0435 \u0441\u043B\u043E\u0432\u043E");
      await updateWords((s) => {
        if (!has(s.known, lemma)) return;
        delete s.known[lemma];
        delete s.outbox.known[lemma];
        s.removedKnown[lemma] = nowStamp();
      });
      return { ok: true };
    }
    case "addVocab": {
      const lemma = normLemma(m.lemma);
      if (lemma === "") return fail2("\u041F\u0443\u0441\u0442\u043E\u0435 \u0441\u043B\u043E\u0432\u043E");
      let fromPack;
      try {
        if ((await getPackStatus()).ready) fromPack = (await lookupWords([lemma]))[lemma];
      } catch {
      }
      const item = {
        book_title: BROWSER_BOOK_TITLE,
        lemma,
        pos: clip(m.pos, 30) || fromPack?.pos || void 0,
        translation: clip(m.translation, MAX_FIELD) || fromPack?.tr[0] || void 0,
        context: clip(m.context, MAX_CONTEXT) || void 0,
        surface: clip(m.surface, MAX_FIELD) || void 0,
        added_at: nowStamp()
      };
      for (const k of Object.keys(item)) if (item[k] === void 0) delete item[k];
      await updateWords((s) => {
        const prev = s.vocab[lemma];
        const merged = prev && has(s.vocab, lemma) ? mergeVocab(prev, item) : item;
        s.vocab[lemma] = merged;
        if (merged.book_title === BROWSER_BOOK_TITLE) s.outbox.vocab[lemma] = merged;
      });
      scheduleSync();
      return { ok: true };
    }
    default:
      break;
  }
  if (!fromExtensionPage) return fail2("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441");
  switch (m.type) {
    case "checkHost":
      return { ok: true, host: await checkHost() };
    case "syncNow":
      return { ok: true, host: await syncNow(true) };
    case "reloadPack":
      return { ok: true, pack: await ensurePack(true) };
    case "addSite": {
      const site = parseSiteInput(String(m.origin ?? ""));
      if (!site) return fail2("\u041D\u0435 \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 \u0430\u0434\u0440\u0435\u0441 \u0441\u0430\u0439\u0442\u0430. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, example.com");
      const err = await addAlwaysSite(site);
      return err ? fail2(err) : { ok: true };
    }
    case "removeSite": {
      const site = siteOf(String(m.origin ?? ""));
      if (!site) return fail2("\u041D\u0435 \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 \u0430\u0434\u0440\u0435\u0441 \u0441\u0430\u0439\u0442\u0430");
      await removeAlwaysSite(site.origin);
      return { ok: true };
    }
    case "excludeSite": {
      const site = parseSiteInput(String(m.host ?? ""));
      if (!site) return fail2("\u041D\u0435 \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 \u0430\u0434\u0440\u0435\u0441 \u0441\u0430\u0439\u0442\u0430. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, example.com");
      await excludeSite(site);
      return { ok: true };
    }
    case "unexcludeSite": {
      await unexcludeSite(String(m.host ?? ""));
      return { ok: true };
    }
    default:
      return fail2("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441");
  }
}

// src/background/index.ts
var SYNC_ALARM = "gr-sync";
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const fromExtensionPage = sender.id === chrome.runtime.id && (sender.url ?? "").startsWith(chrome.runtime.getURL(""));
  handleMessage(msg, fromExtensionPage).then(sendResponse, (e) => {
    sendResponse({ ok: false, error: e instanceof Error ? e.message : String(e) });
  });
  return true;
});
chrome.action.onClicked.addListener((tab) => {
  void toggleInTab(tab);
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  void onMenuClick(info, tab).catch((e) => console.warn("GlossReader: \u043C\u0435\u043D\u044E \u0437\u043D\u0430\u0447\u043A\u0430", e));
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === SYNC_ALARM) void syncNow().catch(() => {
  });
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.settings) return;
  void broadcastRescan();
  void reconcileScripts();
});
chrome.runtime.onInstalled.addListener(() => {
  void createMenus().catch((e) => console.warn("GlossReader: \u043C\u0435\u043D\u044E \u0437\u043D\u0430\u0447\u043A\u0430", e));
  void syncNow().catch(() => {
  });
});
chrome.runtime.onStartup.addListener(() => {
  void syncNow().catch(() => {
  });
});
async function init() {
  const alarm = await chrome.alarms.get(SYNC_ALARM);
  if (!alarm) chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 5 });
  void reconcileScripts();
  await ensurePack();
  await syncIfStale();
}
void init().catch((e) => console.warn("GlossReader: \u0437\u0430\u043F\u0443\u0441\u043A", e));
//# sourceMappingURL=background.js.map
