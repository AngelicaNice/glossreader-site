"use strict";
(() => {
  // ../frontend/src/lib/levels.ts
  var CEFR_LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"];
  var FREQ_LEVELS = ["TOP1000", "TOP5000", "TOP20000", "RARE"];
  var PHRASE_LEVELS = ["PHRASE"];
  var LEVELS = [...CEFR_LEVELS, ...FREQ_LEVELS, ...PHRASE_LEVELS];
  var GLOSSARY_SCALES = [
    { size: 2e3, label: "2\u041A Schmitt", title: "St\xE6hr/Schmitt: 2000 \u0441\u0430\u043C\u044B\u0445 \u0447\u0430\u0441\u0442\u044B\u0445 \u0441\u0435\u043C\u0435\u0439 \u2014 \u043F\u043E\u0440\u043E\u0433 \u0441\u0440\u0435\u0434\u043D\u0435\u0433\u043E \u0443\u0440\u043E\u0432\u043D\u044F" },
    { size: 3e3, label: "3\u041A Nation", title: "Nation: 3000 \u0441\u0435\u043C\u0435\u0439 \u043F\u043E\u043A\u0440\u044B\u0432\u0430\u044E\u0442 ~95% \u0443\u0441\u0442\u043D\u043E\u0439 \u0440\u0435\u0447\u0438" },
    { size: 5e3, label: "5\u041A Milton", title: "Milton XLex: 5000 \u043B\u0435\u043C\u043C \u2014 \u0448\u043A\u0430\u043B\u0430 \u043A\u0435\u043C\u0431\u0440\u0438\u0434\u0436\u0441\u043A\u0438\u0445 \u044D\u043A\u0437\u0430\u043C\u0435\u043D\u043E\u0432" },
    { size: 9e3, label: "9\u041A \u0440\u043E\u043C\u0430\u043D\u044B", title: "Nation: 8000\u20139000 \u0441\u0435\u043C\u0435\u0439 \u043F\u043E\u043A\u0440\u044B\u0432\u0430\u044E\u0442 ~98% \u0440\u043E\u043C\u0430\u043D\u043E\u0432" }
  ];
  var GLOSSARY_SIZES = GLOSSARY_SCALES.map((s) => s.size);
  var LEVEL_LABELS = {
    A1: "A1",
    A2: "A2",
    B1: "B1",
    B2: "B2",
    C1: "C1",
    C2: "C2",
    TOP1000: "\u0442\u043E\u043F-1\u041A",
    TOP5000: "\u0442\u043E\u043F-5\u041A",
    TOP20000: "\u0442\u043E\u043F-20\u041A",
    RARE: "\u0440\u0435\u0434\u043A\u0438\u0435",
    PHRASE: "\u0444\u0440\u0430\u0437\u044B"
  };
  var LEVEL_COLORS = {
    A1: "rgba(139, 195, 74, 0.4)",
    A2: "rgba(205, 220, 57, 0.4)",
    B1: "rgba(255, 235, 59, 0.45)",
    B2: "rgba(255, 152, 0, 0.35)",
    C1: "rgba(244, 67, 54, 0.3)",
    C2: "rgba(156, 39, 176, 0.3)",
    TOP1000: "rgba(179, 229, 252, 0.55)",
    TOP5000: "rgba(79, 195, 247, 0.4)",
    TOP20000: "rgba(2, 136, 209, 0.3)",
    RARE: "rgba(13, 71, 161, 0.3)",
    PHRASE: "rgba(0, 150, 136, 0.22)"
  };

  // src/shared/types.ts
  var BROWSER_BOOK_TITLE = "\u0418\u0437 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0430";
  var DEFAULT_SETTINGS = {
    enabledLevels: ["A1", "A2", "B1", "B2", "C1", "C2", "TOP1000", "TOP5000", "TOP20000", "RARE"],
    levelsOn: true,
    alwaysSites: [],
    excludeHosts: []
  };

  // src/background/lexmerge.ts
  var MAX_LEXICON_BYTES = 16 << 20;
  function emptyState() {
    return { known: {}, vocab: {}, outbox: { known: {}, vocab: {} }, removedKnown: {} };
  }
  function normLemma(s) {
    if (typeof s !== "string") return "";
    const l = s.trim().toLowerCase();
    return l === "__proto__" ? "" : l;
  }
  var has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  function earlierAt(a, b) {
    a = a.trim();
    b = b.trim();
    if (a === "") return b;
    if (b === "") return a;
    return b < a ? b : a;
  }
  function mergeVocab(a, b) {
    const out = { ...a };
    if (!out.pos) out.pos = b.pos;
    if (!out.translation) out.translation = b.translation;
    if (!out.context) out.context = b.context;
    if (!out.surface) out.surface = b.surface;
    if (!out.added_at || b.added_at && b.added_at < out.added_at) out.added_at = b.added_at;
    return dropEmpty(out);
  }
  function dropEmpty(v) {
    const out = { book_title: v.book_title, lemma: v.lemma };
    if (v.pos) out.pos = v.pos;
    if (v.translation) out.translation = v.translation;
    if (v.context) out.context = v.context;
    if (v.surface) out.surface = v.surface;
    if (v.added_at) out.added_at = v.added_at;
    return out;
  }
  function cleanVocab(v) {
    if (typeof v !== "object" || v === null) return null;
    const r = v;
    const str = (x) => typeof x === "string" ? x : "";
    const title = str(r.book_title).trim();
    const lemma = normLemma(r.lemma);
    if (title === "" || lemma === "") return null;
    return dropEmpty({
      book_title: title,
      lemma,
      pos: str(r.pos),
      translation: str(r.translation),
      context: str(r.context),
      surface: str(r.surface),
      added_at: str(r.added_at)
    });
  }
  function mergeSnapshots(...parts) {
    const dismissed = /* @__PURE__ */ new Map();
    const vocab = /* @__PURE__ */ new Map();
    for (const part of parts) {
      for (const d of part.dismissed ?? []) {
        const r = d;
        const lemma = normLemma(r?.lemma);
        if (lemma === "") continue;
        const at = typeof r?.at === "string" ? r.at.trim() : "";
        const prev = dismissed.get(lemma);
        dismissed.set(lemma, { lemma, at: prev ? earlierAt(prev.at, at) : at });
      }
      for (const raw of part.vocab ?? []) {
        const v = cleanVocab(raw);
        if (!v) continue;
        const key = v.book_title.toLowerCase() + "\0" + v.lemma;
        const prev = vocab.get(key);
        vocab.set(key, prev ? mergeVocab(prev, v) : v);
      }
    }
    const byLemma = (a, b) => a.lemma < b.lemma ? -1 : a.lemma > b.lemma ? 1 : 0;
    return {
      dismissed: [...dismissed.values()].sort(byLemma),
      vocab: [...vocab.values()].sort((a, b) => {
        const x = a.book_title.toLowerCase();
        const y = b.book_title.toLowerCase();
        return x !== y ? x < y ? -1 : 1 : byLemma(a, b);
      }),
      progress: []
    };
  }
  function parseLexiconFile(text, byteLength = text.length) {
    if (byteLength > MAX_LEXICON_BYTES) {
      return { ok: false, error: "\u0424\u0430\u0439\u043B \u0431\u043E\u043B\u044C\u0448\u0435 16 \u041C\u0411: \u044D\u0442\u043E \u043D\u0435 \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 lexicon.json." };
    }
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return { ok: false, error: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0444\u0430\u0439\u043B: \u044D\u0442\u043E \u043D\u0435 JSON. \u041D\u0443\u0436\u0435\u043D \u0444\u0430\u0439\u043B lexicon.json \u0438\u0437 GlossReader." };
    }
    if (typeof data !== "object" || data === null || Array.isArray(data)) {
      return { ok: false, error: "\u0412 \u0444\u0430\u0439\u043B\u0435 \u043D\u0435\u0442 \u0441\u043F\u0438\u0441\u043A\u043E\u0432 \u0441\u043B\u043E\u0432. \u041D\u0443\u0436\u0435\u043D \u0444\u0430\u0439\u043B lexicon.json \u0438\u0437 GlossReader." };
    }
    const o = data;
    const hasD = Array.isArray(o.dismissed);
    const hasV = Array.isArray(o.vocab);
    if (!hasD && !hasV) {
      return { ok: false, error: "\u0412 \u0444\u0430\u0439\u043B\u0435 \u043D\u0435\u0442 \u0441\u043F\u0438\u0441\u043A\u043E\u0432 \u0441\u043B\u043E\u0432 (dismissed \u0438 vocab). \u041D\u0443\u0436\u0435\u043D \u0444\u0430\u0439\u043B lexicon.json \u0438\u0437 GlossReader." };
    }
    if (o.dismissed !== void 0 && o.dismissed !== null && !hasD || o.vocab !== void 0 && o.vocab !== null && !hasV) {
      return { ok: false, error: "\u0424\u0430\u0439\u043B \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D: \u0441\u043F\u0438\u0441\u043A\u0438 \u0441\u043B\u043E\u0432 \u0437\u0430\u043F\u0438\u0441\u0430\u043D\u044B \u043D\u0435 \u0442\u0430\u043A, \u043A\u0430\u043A \u0432 lexicon.json." };
    }
    const dismissedIn = hasD ? o.dismissed : [];
    const vocabIn = hasV ? o.vocab : [];
    const snapshot = mergeSnapshots({ dismissed: dismissedIn, vocab: vocabIn });
    let skipped = 0;
    for (const d of dismissedIn) if (normLemma(d?.lemma) === "") skipped++;
    for (const v of vocabIn) if (cleanVocab(v) === null) skipped++;
    return { ok: true, snapshot, skipped };
  }
  function buildSnapshot(known, vocab) {
    return mergeSnapshots(
      { dismissed: Object.entries(known).map(([lemma, at]) => ({ lemma, at })) },
      { vocab: Object.values(vocab) }
    );
  }
  function serializeSnapshot(s) {
    return JSON.stringify(s, null, 2) + "\n";
  }
  var isBrowserBook = (title) => title.trim().toLowerCase() === BROWSER_BOOK_TITLE.toLowerCase();
  function applySnapshot(state, snap, mode) {
    const stats = { knownAdded: 0, knownSame: 0, knownIgnored: 0, vocabAdded: 0, vocabSame: 0 };
    for (const d of snap.dismissed ?? []) {
      const r = d;
      const lemma = normLemma(r?.lemma);
      if (lemma === "") continue;
      const at = typeof r?.at === "string" ? r.at.trim() : "";
      if (has(state.removedKnown, lemma)) {
        if (at <= state.removedKnown[lemma]) {
          stats.knownIgnored++;
          continue;
        }
        delete state.removedKnown[lemma];
      }
      if (has(state.known, lemma)) {
        stats.knownSame++;
        state.known[lemma] = earlierAt(state.known[lemma], at);
      } else {
        stats.knownAdded++;
        state.known[lemma] = at;
        if (mode === "import") state.outbox.known[lemma] = at;
      }
      if (mode === "host") delete state.outbox.known[lemma];
    }
    for (const raw of snap.vocab ?? []) {
      const v = cleanVocab(raw);
      if (!v) continue;
      const mine = isBrowserBook(v.book_title);
      if (has(state.vocab, v.lemma)) {
        stats.vocabSame++;
        state.vocab[v.lemma] = mergeVocab(state.vocab[v.lemma], v);
      } else {
        stats.vocabAdded++;
        state.vocab[v.lemma] = v;
        if (mode === "import" && mine) state.outbox.vocab[v.lemma] = v;
      }
      if (mode === "host" && mine) delete state.outbox.vocab[v.lemma];
    }
    return stats;
  }

  // src/background/native.ts
  var NOT_CONNECTED = "\u041F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 GlossReader \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E: \u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u2192 \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0431\u0440\u0430\u0443\u0437\u0435\u0440";
  var MAX_PAUSE_MS = 5 * 6e4;

  // src/background/store.ts
  var LOCK_NAME = "gr-store";
  async function withStore(fn) {
    if (typeof navigator !== "undefined" && navigator.locks) {
      return navigator.locks.request(LOCK_NAME, fn);
    }
    return fn();
  }
  async function readWords() {
    const r = await chrome.storage.local.get(["known", "vocab", "outbox", "removedKnown"]);
    const s = emptyState();
    if (isMap(r.known)) s.known = r.known;
    if (isMap(r.vocab)) s.vocab = r.vocab;
    if (isMap(r.removedKnown)) s.removedKnown = r.removedKnown;
    if (isMap(r.outbox)) {
      const o = r.outbox;
      if (isMap(o.known)) s.outbox.known = o.known;
      if (isMap(o.vocab)) s.outbox.vocab = o.vocab;
    }
    return s;
  }
  async function writeWords(s) {
    await chrome.storage.local.set({ known: s.known, vocab: s.vocab, outbox: s.outbox, removedKnown: s.removedKnown });
  }
  function updateWords(fn) {
    return withStore(async () => {
      const s = await readWords();
      const out = await fn(s);
      await writeWords(s);
      return out;
    });
  }
  function isMap(x) {
    return typeof x === "object" && x !== null && !Array.isArray(x);
  }
  async function getSettings() {
    const r = await chrome.storage.local.get("settings");
    return normalizeSettings(r.settings);
  }
  function normalizeSettings(raw) {
    const o = isMap(raw) ? raw : {};
    const list = (x, fallback) => Array.isArray(x) ? x.filter((v) => typeof v === "string") : fallback;
    return {
      enabledLevels: list(o.enabledLevels, DEFAULT_SETTINGS.enabledLevels),
      levelsOn: typeof o.levelsOn === "boolean" ? o.levelsOn : DEFAULT_SETTINGS.levelsOn,
      alwaysSites: list(o.alwaysSites, []),
      excludeHosts: list(o.excludeHosts, [])
    };
  }
  function updateSettings(fn) {
    return withStore(async () => {
      const s = await getSettings();
      fn(s);
      await chrome.storage.local.set({ settings: s });
      return s;
    });
  }
  async function getHostStatus() {
    const r = await chrome.storage.local.get("host");
    return isMap(r.host) ? r.host : { connected: false };
  }
  async function getPackStatus() {
    const r = await chrome.storage.local.get("packState");
    return isMap(r.packState) ? r.packState : { ready: false, loading: false, progress: 0 };
  }

  // src/background/sites.ts
  function siteOf(url) {
    if (!url) return null;
    try {
      const u = new URL(url);
      if (u.protocol !== "http:" && u.protocol !== "https:") return null;
      if (u.hostname === "") return null;
      return { origin: u.origin, host: u.hostname };
    } catch {
      return null;
    }
  }
  function parseSiteInput(text) {
    const t = text.trim();
    if (t === "" || /\s/.test(t)) return null;
    const site = siteOf(/^[a-z][a-z0-9+.-]*:\/\//i.test(t) ? t : "https://" + t);
    if (!site) return null;
    if (!site.host.includes(".") && site.host !== "localhost") return null;
    return site;
  }
  var patternOf = (origin) => origin + "/*";
  var reconciling = Promise.resolve();

  // src/options/licenses.ts
  var INLINE = /\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|(https?:\/\/[^\s)\]]+[^\s)\].,;])|\*([^*\n]+)\*/g;
  function parseInline(text) {
    const out = [];
    const plain = (s) => s.replace(/`/g, "").replace(/\*\*/g, "");
    let last = 0;
    for (const m of text.matchAll(INLINE)) {
      const at = m.index ?? 0;
      if (at > last) out.push({ t: "text", s: plain(text.slice(last, at)) });
      if (m[2] !== void 0) out.push({ t: "link", s: plain(m[1]), href: m[2] });
      else if (m[3] !== void 0) out.push({ t: "link", s: m[3], href: m[3] });
      else out.push({ t: "em", s: plain(m[4]) });
      last = at + m[0].length;
    }
    if (last < text.length) out.push({ t: "text", s: plain(text.slice(last)) });
    return out.filter((i) => i.s !== "");
  }
  var isTableRow = (l) => l.trimStart().startsWith("|");
  function parseLicenseText(text) {
    const blocks = [];
    const lines = text.replace(/\r\n?/g, "\n").split("\n");
    let para = [];
    const flush = () => {
      if (para.length) blocks.push({ kind: "para", inline: parseInline(para.join(" ")) });
      para = [];
    };
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const h = /^(#{1,6})\s+(.*)$/.exec(line);
      if (h) {
        flush();
        const level = Math.min(5, Math.max(3, h[1].length + 2));
        blocks.push({ kind: "heading", level, text: h[2].replace(/`/g, "").trim() });
      } else if (isTableRow(line)) {
        flush();
        const cells = line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((c) => c.trim());
        const separator = cells.every((c) => /^:?-{3,}:?$/.test(c));
        const header = i + 1 < lines.length && isTableRow(lines[i + 1]) && lines[i + 1].replace(/[|\s:-]/g, "") === "";
        if (separator || header) continue;
        blocks.push({ kind: "row", name: cells[0].replace(/`/g, ""), inline: parseInline(cells.slice(1).join(" | ")) });
      } else if (line.trim() === "") {
        flush();
      } else if (/^\s*(\d+\.|[-*])\s/.test(line)) {
        flush();
        para.push(line.trim());
        flush();
      } else {
        para.push(line.trim());
      }
    }
    flush();
    return blocks;
  }

  // src/options/index.ts
  var $ = (id) => {
    const el2 = document.getElementById(id);
    if (!el2) throw new Error("\u043D\u0435\u0442 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430 #" + id);
    return el2;
  };
  function el(tag, props = {}, ...children) {
    const e = Object.assign(document.createElement(tag), props);
    for (const c of children) e.append(c);
    return e;
  }
  var when = (iso) => {
    if (!iso) return "\u2014";
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? "\u2014" : d.toLocaleString("ru-RU");
  };
  async function send(msg) {
    try {
      return await chrome.runtime.sendMessage(msg) ?? { ok: false, error: "\u0424\u043E\u043D\u043E\u0432\u044B\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u043D\u0435 \u043E\u0442\u0432\u0435\u0442\u0438\u043B" };
    } catch (e) {
      return { ok: false, error: "\u0424\u043E\u043D\u043E\u0432\u044B\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u043D\u0435 \u043E\u0442\u0432\u0435\u0442\u0438\u043B: " + (e instanceof Error ? e.message : String(e)) };
    }
  }
  var hostBusy = false;
  async function renderHost() {
    const host = await getHostStatus();
    const { outbox } = await readWords();
    const status = $("host-status");
    status.textContent = host.connected ? "\u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E" : "\u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u043E";
    status.className = "status " + (host.connected ? "ok" : "bad");
    const note = $("host-error");
    if (host.connected) {
      note.hidden = true;
    } else {
      note.hidden = false;
      note.textContent = host.error ?? (host.checkedAt ? NOT_CONNECTED : "\u0421\u0432\u044F\u0437\u044C \u0441 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C \u0435\u0449\u0451 \u043D\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u043B\u0430\u0441\u044C. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u0432\u044F\u0437\u044C\xBB.");
    }
    $("host-version").textContent = host.version ?? "\u2014";
    $("host-path").textContent = host.lexicon || "\u2014";
    $("host-synced").textContent = when(host.syncedAt);
    const waiting = Object.keys(outbox.known).length + Object.keys(outbox.vocab).length;
    $("host-outbox").textContent = waiting === 0 ? "\u043D\u0435\u0442" : `${waiting} (\u043E\u0442\u043F\u0440\u0430\u0432\u044F\u0442\u0441\u044F \u043F\u0440\u0438 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u043C \u043E\u0431\u043C\u0435\u043D\u0435)`;
    for (const id of ["btn-check", "btn-sync"]) $(id).disabled = hostBusy;
  }
  async function runHost(kind, button, busyText) {
    const label = button.textContent;
    hostBusy = true;
    button.textContent = busyText;
    await renderHost();
    await send({ type: kind });
    hostBusy = false;
    button.textContent = label;
    await renderHost();
  }
  async function renderWords() {
    const { known, vocab } = await readWords();
    $("count-known").textContent = String(Object.keys(known).length);
    $("count-vocab").textContent = String(Object.keys(vocab).length);
  }
  async function exportWords() {
    const { known, vocab } = await readWords();
    const text = serializeSnapshot(buildSnapshot(known, vocab));
    const url = URL.createObjectURL(new Blob([text], { type: "application/json" }));
    const a = el("a", { href: url, download: "lexicon.json" });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  }
  function showImport(text, bad) {
    const p = $("import-result");
    p.hidden = false;
    p.className = "result" + (bad ? " bad" : "");
    p.textContent = text;
  }
  async function importWords(file) {
    if (file.size > MAX_LEXICON_BYTES) {
      showImport("\u0424\u0430\u0439\u043B \u0431\u043E\u043B\u044C\u0448\u0435 16 \u041C\u0411: \u044D\u0442\u043E \u043D\u0435 \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 lexicon.json. \u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C.", true);
      return;
    }
    let text;
    try {
      text = await file.text();
    } catch {
      showImport("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0444\u0430\u0439\u043B. \u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C.", true);
      return;
    }
    const parsed = parseLexiconFile(text, file.size);
    if (!parsed.ok) {
      showImport(parsed.error + " \u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C.", true);
      return;
    }
    const stats = await updateWords((s) => applySnapshot(s, parsed.snapshot, "import"));
    const lines = [`\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u043E: \xAB\u0437\u043D\u0430\u044E\xBB \u2014 ${stats.knownAdded}, \u0441\u043B\u043E\u0432 \u0432 \u0441\u043B\u043E\u0432\u0430\u0440\u0435 \u2014 ${stats.vocabAdded}.`];
    const same = stats.knownSame + stats.vocabSame;
    if (same > 0) lines.push(`\u0423\u0436\u0435 \u0431\u044B\u043B\u0438: ${same}.`);
    if (stats.knownIgnored > 0) lines.push(`\u041D\u0435 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u043E \u0441\u043B\u043E\u0432, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0432\u044B \u0441\u043D\u044F\u043B\u0438 \u0441 \xAB\u0437\u043D\u0430\u044E\xBB \u0437\u0434\u0435\u0441\u044C: ${stats.knownIgnored}.`);
    if (parsed.skipped > 0) lines.push(`\u041F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043E \u0441\u0442\u0440\u043E\u043A, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u043D\u0435 \u043F\u043E\u0445\u043E\u0436\u0438 \u043D\u0430 \u0441\u043B\u043E\u0432\u043E: ${parsed.skipped}.`);
    showImport(lines.join(" "), false);
    if (stats.knownAdded + stats.vocabAdded > 0) void send({ type: "syncNow" });
  }
  var SHOWN_LEVELS = [...CEFR_LEVELS, ...FREQ_LEVELS];
  async function renderLevels() {
    const s = await getSettings();
    $("levels-on").checked = s.levelsOn;
    const box = $("levels");
    box.classList.toggle("off", !s.levelsOn);
    box.replaceChildren(
      ...SHOWN_LEVELS.map((lvl) => {
        const input = el("input", { type: "checkbox", checked: s.enabledLevels.includes(lvl), disabled: !s.levelsOn });
        input.dataset.level = lvl;
        const swatch = el("span", { className: "swatch" });
        swatch.style.background = LEVEL_COLORS[lvl];
        return el("label", {}, input, swatch, LEVEL_LABELS[lvl]);
      })
    );
  }
  function bindLevels() {
    $("levels-on").addEventListener("change", async (e) => {
      const on = e.target.checked;
      await updateSettings((s) => {
        s.levelsOn = on;
      });
    });
    $("levels").addEventListener("change", async (e) => {
      const input = e.target;
      const lvl = input.dataset.level;
      if (!lvl) return;
      await updateSettings((s) => {
        const keep = s.enabledLevels.filter((l) => !SHOWN_LEVELS.includes(l));
        const chosen = new Set(s.enabledLevels.filter((l) => SHOWN_LEVELS.includes(l)));
        if (input.checked) chosen.add(lvl);
        else chosen.delete(lvl);
        s.enabledLevels = [...keep, ...SHOWN_LEVELS.filter((l) => chosen.has(l))];
      });
    });
  }
  async function allowed(origin) {
    try {
      return await chrome.permissions.contains({ origins: [patternOf(origin)] });
    } catch {
      return false;
    }
  }
  async function renderSites() {
    const s = await getSettings();
    const always = $("always-list");
    const rows = await Promise.all(
      s.alwaysSites.map(async (origin) => {
        const name = el("span", { className: "name" }, origin);
        const buttons = [];
        if (!await allowed(origin)) {
          name.append(el("span", { className: "muted small" }, " \u2014 \u043D\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0438\u044F"));
          const allow = el("button", { type: "button", textContent: "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044C" });
          allow.addEventListener("click", async () => {
            if (await chrome.permissions.request({ origins: [patternOf(origin)] })) await send({ type: "addSite", origin });
            await renderSites();
          });
          buttons.push(allow);
        }
        const remove = el("button", { type: "button", textContent: "\u0423\u0431\u0440\u0430\u0442\u044C" });
        remove.setAttribute("aria-label", "\u0423\u0431\u0440\u0430\u0442\u044C " + origin);
        remove.addEventListener("click", async () => {
          await send({ type: "removeSite", origin });
        });
        buttons.push(remove);
        return el("li", {}, name, el("span", { className: "row" }, ...buttons));
      })
    );
    always.replaceChildren(...rows.length ? rows : [el("li", { className: "empty" }, "\u041F\u043E\u043A\u0430 \u043D\u0435\u0442 \u0441\u0430\u0439\u0442\u043E\u0432.")]);
    const excluded = $("exclude-list");
    excluded.replaceChildren(
      ...s.excludeHosts.length ? s.excludeHosts.map((host) => {
        const remove = el("button", { type: "button", textContent: "\u0423\u0431\u0440\u0430\u0442\u044C" });
        remove.setAttribute("aria-label", "\u0423\u0431\u0440\u0430\u0442\u044C " + host);
        remove.addEventListener("click", async () => {
          await send({ type: "unexcludeSite", host });
        });
        return el("li", {}, el("span", { className: "name" }, host), remove);
      }) : [el("li", { className: "empty" }, "\u041F\u043E\u043A\u0430 \u043D\u0435\u0442 \u0441\u0430\u0439\u0442\u043E\u0432.")]
    );
  }
  function showSiteError(id, text) {
    const p = $(id);
    p.hidden = text === null;
    p.textContent = text ?? "";
  }
  function bindSites() {
    $("always-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const input = $("always-input");
      const site = parseSiteInput(input.value);
      if (!site) {
        showSiteError("always-error", "\u041D\u0435 \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 \u0430\u0434\u0440\u0435\u0441 \u0441\u0430\u0439\u0442\u0430. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, example.com");
        return;
      }
      let granted = false;
      try {
        granted = await chrome.permissions.request({ origins: [patternOf(site.origin)] });
      } catch (err) {
        showSiteError("always-error", "\u0411\u0440\u0430\u0443\u0437\u0435\u0440 \u043D\u0435 \u0434\u0430\u043B \u0437\u0430\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u0434\u043E\u0441\u0442\u0443\u043F: " + (err instanceof Error ? err.message : String(err)));
        return;
      }
      if (!granted) {
        showSiteError("always-error", "\u0414\u043E\u0441\u0442\u0443\u043F \u043A \u0441\u0430\u0439\u0442\u0443 \u043D\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D, \u043F\u043E\u044D\u0442\u043E\u043C\u0443 \u043E\u043D \u043D\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D.");
        return;
      }
      const r = await send({ type: "addSite", origin: site.origin });
      if (r.ok === true) {
        showSiteError("always-error", null);
        input.value = "";
      } else {
        showSiteError("always-error", String(r.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0441\u0430\u0439\u0442"));
      }
    });
    $("exclude-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const input = $("exclude-input");
      const site = parseSiteInput(input.value);
      if (!site) {
        showSiteError("exclude-error", "\u041D\u0435 \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 \u0430\u0434\u0440\u0435\u0441 \u0441\u0430\u0439\u0442\u0430. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, example.com");
        return;
      }
      const r = await send({ type: "excludeSite", host: site.host });
      if (r.ok === true) {
        showSiteError("exclude-error", null);
        input.value = "";
      } else {
        showSiteError("exclude-error", String(r.error ?? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0441\u0430\u0439\u0442"));
      }
    });
  }
  async function renderPack() {
    const p = await getPackStatus();
    const status = $("pack-status");
    if (p.ready) {
      status.textContent = "\u0433\u043E\u0442\u043E\u0432";
      status.className = "status ok";
    } else if (p.loading) {
      status.textContent = `\u0437\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u0442\u0441\u044F\u2026 ${Math.round(p.progress * 100)}%`;
      status.className = "status";
    } else if (p.error) {
      status.textContent = "\u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D";
      status.className = "status bad";
    } else {
      status.textContent = "\u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D";
      status.className = "status";
    }
    $("pack-count").textContent = p.count !== void 0 ? p.count.toLocaleString("ru-RU") : "\u2014";
    $("pack-version").textContent = p.version !== void 0 ? String(p.version) : "\u2014";
    $("pack-built").textContent = p.built ?? "\u2014";
    const btn = $("btn-pack");
    btn.hidden = !(p.error && !p.loading);
    if (p.error) status.title = p.error;
  }
  function inlineNodes(parts) {
    return parts.map((i) => {
      if (i.t === "link") return el("a", { href: i.href, target: "_blank", rel: "noopener noreferrer", textContent: i.s });
      if (i.t === "em") return el("em", { textContent: i.s });
      return document.createTextNode(i.s);
    });
  }
  function blockNode(b) {
    if (b.kind === "heading") return el(`h${b.level}`, { textContent: b.text });
    if (b.kind === "row") return el("p", {}, el("strong", { textContent: b.name }), ": ", ...inlineNodes(b.inline));
    return el("p", {}, ...inlineNodes(b.inline));
  }
  async function renderLicenses() {
    const box = $("licenses");
    try {
      const res = await fetch(chrome.runtime.getURL("ATTRIBUTION.md"));
      if (!res.ok) throw new Error(String(res.status));
      box.replaceChildren(...parseLicenseText(await res.text()).map(blockNode));
    } catch {
      box.textContent = "\u0422\u0435\u043A\u0441\u0442 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0439 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0432 \u043F\u0430\u043A\u0435\u0442\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F. \u041E\u043D \u0435\u0441\u0442\u044C \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438 GlossReader: \u041E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438 \u2192 \u041B\u0438\u0446\u0435\u043D\u0437\u0438\u0438 \u0438 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438 \u0434\u0430\u043D\u043D\u044B\u0445.";
    }
  }
  async function renderAll() {
    await Promise.all([renderHost(), renderWords(), renderLevels(), renderSites(), renderPack()]);
  }
  function bind() {
    $("btn-check").addEventListener("click", () => void runHost("checkHost", $("btn-check"), "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u2026"));
    $("btn-sync").addEventListener("click", () => void runHost("syncNow", $("btn-sync"), "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u2026"));
    $("btn-export").addEventListener("click", () => void exportWords());
    const file = $("file-import");
    file.addEventListener("change", async () => {
      const f = file.files?.[0];
      if (f) await importWords(f);
      file.value = "";
    });
    $("btn-import").addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        file.click();
      }
    });
    $("btn-pack").addEventListener("click", () => void send({ type: "reloadPack" }));
    bindLevels();
    bindSites();
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.host || changes.outbox) void renderHost();
    if (changes.known || changes.vocab) void renderWords();
    if (changes.settings) {
      void renderLevels();
      void renderSites();
    }
    if (changes.packState) void renderPack();
  });
  var version = chrome.runtime.getManifest().version;
  $("version").textContent = version;
  bind();
  void renderAll();
  void renderLicenses();
})();
//# sourceMappingURL=options.js.map
